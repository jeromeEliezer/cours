/*

Auteur : Laurent BRACQUART <lbracquart@atalan.fr>
URL : http://atalan.fr/
Date de création : 26 Mai 2011
Version : 1.0

Index :

    0/ Gestion de l'affichage du menu déroulant à la souris et au clavier

    Annexes/ Fonctions annexes

*/

$(document).ready(function()
{
	// 0/ Gestion de l'affichage du menu déroulant à la souris et au clavier
	$('ul#menu > li > ul')
		.addClass('cache')
		.parent().bind('mouseover focusin', function()
		{
			$(this).find('ul').removeClass('cache');
		}).bind('mouseout focusout', function()
		{
			$(this).find('ul').addClass('cache');
		});
});

// Annexes/ Fonctions annexes