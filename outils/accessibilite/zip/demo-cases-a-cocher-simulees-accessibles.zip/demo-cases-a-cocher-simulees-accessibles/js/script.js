/*

Auteur : Laurent BRACQUART <lbracquart@atalan.fr>
URL : http://atalan.fr/
Date de création : 11 septembre 2012
Version : 1.0

Index :

    0/ Gestion des checkboxes simulées en ARIA

    Annexes/ Fonctions annexes

*/

$(document).ready(function()
{
	// 0/ Gestion des checkboxes simulées en ARIA
	$reponses = $('ul#reponses');
	$choix = $reponses.find('li.choix');
	$checkbox = $('<img />',
	{
		'aria-hidden':		'true',
		'src':				'images/checkbox-neutre.png',
		'alt':				'Non coché : '
	});
	
	$reponses
		.attr(
		{
			'role':				'group',
			'aria-labelledby':	'question'
		});
	
	$choix
		.each(function ()
		{
			$this = $(this);
		
			$this
				.text($this.text());
		})
		.attr(
		{
			'role':				'checkbox',
			'aria-checked':		'false',
			'tabindex':			'0'
		})
		.prepend($checkbox)
		.on('click keydown', function(e)
		{
			var $this = $(this),
				$etat = $this.attr('aria-checked');
			
			if(e.type == 'click' || e.type == 'keydown' && e.keyCode == '32')
			{
				cocher($this, $etat);
			}
		});
});

// Annexes/ Fonctions annexes

// Coche les checkboxes simulées en ARIA
//
// Gère :
// - Les aria-checked.
//
// Prend en paramètre :
// - Un objet jQuery, la checkbox.
// - L'état actuel de la checkbox.
//
// Retourne :
// - L'objet passé en paramètre.
function cocher($checkbox, $etat)
{
	if($etat == 'false')
	{
		$checkbox
		.attr('aria-checked', 'true')
			.find('img')
				.remplacerAttribut('src', 'neutre', 'active')
				.remplacerAttribut('alt', 'Non coché', 'Coché');
	}
	else
	{
		$checkbox
		.attr('aria-checked', 'false')
			.find('img')
				.remplacerAttribut('src', 'active', 'neutre')
				.remplacerAttribut('alt', 'Coché', 'Non coché');
	}

	return $checkbox;
}

// Remplace une chaîne par une autre dans un attribut
//
// Prend en paramètre :
// - La valeur d'un attribut.
// - La chaîne à rechercher.
// - La chaîne à injecter.
//
// Retourne :
// - Un objet jQuery mis à jour.
$.fn.remplacerAttribut = function(attribut, chaineARechercher, chaineAInjecter)
{
    return this.attr
	(
        attribut,
        function()
		{
            return $(this).attr(attribut).replace(chaineARechercher, chaineAInjecter);
        }
    );
};