/*

Auteur : Laurent BRACQUART <lbracquart@atalan.fr>
URL : http://atalan.fr/
Date de création : 10 septembre 2012
Version : 1.0

Index :

    0/ Gestion de l'affichage de l'infobulle simulée en ARIA

    Annexes/ Fonctions annexes

*/

$(document).ready(function()
{
	// 0/ Gestion de l'affichage de l'infobulle simulée en ARIA
	$('a.infobulle')
		.on('focus mouseenter', function()
		{
			$this = $(this);
			
			$('<div>',
			{
				'class':	'conteneur-infobulle',
				'text':		$this.attr('aria-label')
			})
				.appendTo('body')
				.offset(
				{
					top: $this.offset().top + 20,
					left: $this.offset().left + $this.width() + 20
					
				});
		}).on('focusout mouseleave', function()
		{
			$('div.conteneur-infobulle').remove();
		});
});

// Annexes/ Fonctions annexes