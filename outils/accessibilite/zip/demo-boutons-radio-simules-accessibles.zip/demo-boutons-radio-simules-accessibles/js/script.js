/*

Auteur : Laurent BRACQUART <lbracquart@atalan.fr>
URL : http://atalan.fr/
Date de création : 12 septembre 2012
Version : 1.0

Index :

    0/ Gestion des boutons radio simulées en ARIA

    Annexes/ Fonctions annexes

*/

$(document).ready(function()
{
	// 0/ Gestion des boutons radio simulées en ARIA
	$reponses = $('ul#reponses');
	$choix = $reponses.find('li.choix');
	$bouton = $('<img />',
	{
		'aria-hidden':		'true',
		'src':				'images/bouton-radio-neutre.png',
		'alt':				'Non coché : '
	});
	
	$reponses
		.attr(
		{
			'role':				'radiogroup',
			'aria-labelledby':	'question'
		});
	
	$choix
		.each(function ()
		{
			$this = $(this);
		
			$this.text($this.text());
		})
		.attr(
		{
			'role':				'radio',
			'aria-checked':		'false',
			'tabindex':			'0'
		})
		.prepend($bouton)
		.on('click keydown', function(e)
		{
			var $this = $(this),
				$etat = $this.attr('aria-checked'),
				$suivant = boutonSuivant($this),
				$precedent = boutonPrecedent($this);
			
			if(e.type == 'click' && $etat == 'false')
			{
				cocher($this);
			}
			else if(e.type == 'keydown')
			{
				// Touche Espace
				if(e.keyCode == '32' && $etat == 'false')
				{
					cocher($this);
				}
				// Touches haut ou gauche
				else if(e.keyCode == '38' || e.keyCode == '37')
				{
					cocher($precedent).focus();
					
					e.preventDefault();
				}
				// Touches bas ou droite
				else if(e.keyCode == '40' || e.keyCode == '39')
				{
					cocher($suivant).focus();
						
					e.preventDefault();
				}
			}
		})
			.filter(function(i)
			{
				return i > 0 && (i + 1) < $choix.length;
			})
			.attr('tabindex', '-1')
});

// Annexes/ Fonctions annexes

// Coche les boutons radios simulés en ARIA
//
// Gère :
// - Les aria-checked.
// - Les tabindex.
//
// Prend en paramètre :
// - Un objet jQuery, le bouton à cocher.
//
// Retourne :
// - L'objet passé en paramètre.
function cocher($bouton)
{
	$bouton
		.attr('aria-checked', 'true')
		.attr('tabindex', '0')
			.find('img')
				.remplacerAttribut('src', 'neutre', 'actif')
				.remplacerAttribut('alt', 'Non coché', 'Coché')
			.end()
		.siblings()
			.attr('tabindex', '-1')
			.attr('aria-checked', 'false')
				.find('img')
					.remplacerAttribut('src', 'actif', 'neutre')
					.remplacerAttribut('alt', 'Coché', 'Non coché')
				.end();

	return $bouton;
}

// Trouve le bouton suivant dans la liste.
// S'il n'y a pas de bouton suivant, retourne
// le premier bouton de la liste.
//
// Prend en paramètre :
// - Un objet jQuery, le bouton courant.
//
// Retourne :
// - Un objet jQuery, le bouton suivant.
function boutonSuivant($bouton)
{
	var $suivant = $bouton.next('li[role=radio]');
	
	if ($suivant.length == 0)
	{
		$suivant = $bouton.siblings().first();
	}
	
	return $suivant;
}

// Trouve le bouton précédent dans la liste.
// S'il n'y a pas de bouton précédent, retourne
// le dernier bouton de la liste.
//
// Prend en paramètre :
// - Un objet jQuery, le bouton courant.
//
// Retourne :
// - Un objet jQuery, le bouton précédent.
function boutonPrecedent($bouton)
{
	var $precedent = $bouton.prev('li[role=radio]');
	
	if ($precedent.length == 0)
	{
		$precedent = $bouton.siblings().last();
	}
	
	return $precedent;
}

// Remplace une chaîne par une autre dans un attribut
//
// Prend en paramètre :
// - La valeur d'un attribut.
// - La chaîne à rechercher.
// - La chaîne à injecter.
//
// Retourne :
// - Un objet jQuery mis à jour.
$.fn.remplacerAttribut = function(attribut, chaineARechercher, chaineAInjecter)
{
    return this.attr
	(
        attribut,
        function()
		{
            return $(this).attr(attribut).replace(chaineARechercher, chaineAInjecter);
        }
    );
};