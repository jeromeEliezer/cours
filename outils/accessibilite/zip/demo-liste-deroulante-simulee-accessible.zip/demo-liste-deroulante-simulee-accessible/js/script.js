/*

Auteur : Laurent BRACQUART <lbracquart@atalan.fr>
URL : http://atalan.fr/
Date de création : 12 septembre 2012
Version : 1.0

Index :

    0/ Gestion de la liste déroulante simulée

    Annexes/ Fonctions annexes

*/

$(document).ready(function()
{
	// 0/ Gestion de la liste déroulante simulée
	$('body').addClass('js');
	
	$liste = $('select');
	$conteneurListe = $('<div class="conteneur-liste" />');
	$conteneurChoix = $('<span class="conteneur-choix">');
	$fleche = $('<img />',
	{
		'alt':		'',
		'src':		'images/fleche.png'
	})
	
	$liste
		.wrap($conteneurListe)
		.after($conteneurChoix)
		.on('change keyup', function(e)
		{
			if (e.type == 'change' || e.type == 'keyup' && (e.keyCode == '37'|| '38' || '39' || '40'))
			{
				$choix = $(this).find('option:selected').text();
			
				$conteneurChoix
					.html($choix)
					.attr('aria-hidden', 'true')
					.append($fleche);
			}
		})
		.on('focus', function()
		{
			$conteneurChoix.addClass('focus');
		})
		.on('blur', function()
		{
			$conteneurChoix.removeClass('focus');
		})
		.change();		
});

// Annexes/ Fonctions annexes